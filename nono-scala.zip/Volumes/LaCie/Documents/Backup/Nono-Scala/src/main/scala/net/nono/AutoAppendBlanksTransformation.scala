package net.nono

import net.nono.CellStatus._

class AutoAppendBlanksTransformation(board: Board) extends BoardTransformation(board) {

  def getCell(row: Int, col: Int): Cell = {
    if (cell(row, col).status == EMPTY && cell(row, col).solution == EMPTY &&
        (cellsAboveSolved(row - 1, col) || cellsBelowSolved(row + 1, col) ||
            cellsLeftSolved(row, col - 1) || cellsRightSolved(row, col + 1)))
      Cell(board.cells(row)(col), CellStatus.BLANKED)
    else
      board.cells(row)(col)
  }

/*
___###_
...XXX.

###_
XXX.

_____
.....

   else if (cell(row, col).solution == FILLED && cell(row, col).status == CROSSED)
      cellsLeftSolved(row, col - 1)
    else if (cell(row, col).solution == EMPTY && (cell(row, col).status == EMPTY || cell(row, col).status == BLANKED) &&
      cell(row, col + 1).status == CROSSED)
      true
    else
      false

*/

  def cellsLeftSolved(row: Int, col: Int): Boolean = {
    if (col < 0)
      cell(row, col + 1).status == CROSSED
    else cell(row, col) match {
      case c if (c.solution == FILLED && c.status == CROSSED) => cellsLeftSolved(row, col - 1)
      case c if (c.solution == EMPTY && (c.status == EMPTY || c.status == BLANKED) && cell(row, col + 1).status == CROSSED) => true
      case _ => false
    }
  }

  def cellsRightSolved(row: Int, col: Int): Boolean = {
    if (col >= board.size)
      cell(row, col - 1).status == CROSSED
    else cell(row, col) match {
      case c if (c.solution == FILLED && c.status == CROSSED) => cellsRightSolved(row, col + 1)
      case c if (c.solution == EMPTY && (c.status == EMPTY || c.status == BLANKED) && cell(row, col - 1).status == CROSSED) => true
      case _ => false
    }
  }

  def cellsAboveSolved(row: Int, col: Int): Boolean = {
    if (row < 0)
      cell(row + 1, col).status == CROSSED
    else cell(row, col) match {
      case c if (c.solution == FILLED && c.status == CROSSED) => cellsAboveSolved(row - 1, col)
      case c if (c.solution == EMPTY && (c.status == EMPTY || c.status == BLANKED) && cell(row + 1, col).status == CROSSED) => true
      case _ => false
    }
  }

  def cellsBelowSolved(row: Int, col: Int): Boolean = {
    if (row >= board.size)
      cell(row - 1, col).status == CROSSED
    else cell(row, col) match {
      case c if (c.solution == FILLED && c.status == CROSSED) => cellsBelowSolved(row + 1, col)
      case c if (c.solution == EMPTY && (c.status == EMPTY || c.status == BLANKED) && cell(row - 1, col).status == CROSSED) => true
      case _ => false
    }
  }

  def cell(row: Int, col: Int): Cell = board.cells(row)(col)
}

