package net.nono

class FillTransformation(board: Board, fillRow: Int, fillCol: Int) extends BoardTransformation(board) {

  def getCell(row: Int, col: Int): Cell = {
    if (board.isRowSolved(row) && row == fillRow && board.cells(row)(col).status == CellStatus.EMPTY)
      Cell(board.cells(row)(col), CellStatus.BLANKED)
    else if (board.isColumnSolved(col) && col == fillCol && board.cells(row)(col).status == CellStatus.EMPTY)
      Cell(board.cells(row)(col), CellStatus.BLANKED)
    else
      board.cells(row)(col)
  }
}

