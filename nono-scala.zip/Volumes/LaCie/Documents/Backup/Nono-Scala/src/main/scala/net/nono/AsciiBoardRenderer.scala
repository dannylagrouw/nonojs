package net.nono

import org.apache.commons.lang.StringUtils
import java.text.SimpleDateFormat

class AsciiBoardRenderer extends BoardRenderer {

  val dateFormat = new SimpleDateFormat("dd-MM-yyyy HH:mm:ss")

  var statusMap = Map(CellStatus.FILLED -> "#", CellStatus.EMPTY -> ".", CellStatus.BLANKED -> "_", CellStatus.CROSSED -> "X")
  statusMap = Map(CellStatus.FILLED -> "\u25a0", CellStatus.EMPTY -> "\u2027", CellStatus.BLANKED -> "\u25a1", CellStatus.CROSSED -> "\u25a0")

  //TODO CellStatus.toString?
  override def renderPlay(board: Board): Board = {
    render(board) { cell => cell.status match {
      case CellStatus.CROSSED => statusMap(CellStatus.CROSSED)
      case CellStatus.BLANKED => statusMap(CellStatus.BLANKED)
      case _ => statusMap(CellStatus.EMPTY)
    }}
  }

  override def renderSolution(board: Board): Board = {
    render(board) { cell => cell.solution match {
      case CellStatus.FILLED => statusMap(CellStatus.FILLED)
      case _ => statusMap(CellStatus.EMPTY)
    }}
  }

  def render(board: Board)(cellToString: (Cell) => String): Board = {
    val rows = board.getRows
    val columns = board.getColumns
    val maxRowGroups = rows.getMaxGroupCount
    val maxColumnGroups = columns.getMaxGroupCount
    val indent = "  " * (maxRowGroups + 1) + "     "
    val horizontalRuler = ("\u2500" * ((maxRowGroups + board.size + (board.size / 5)) * 2 + 9) + "\n")
    println(
      Range(0, maxColumnGroups).foldLeft("") { (s, colNo) =>
        s + indent + columnsToString(columns.strips, colNo) + "\n"
      } +
      horizontalRuler +
      indent +
      Range(1, board.size + 1).map(i => StringUtils.leftPad(i.toString, 2) + addRuler(i - 1)).mkString("") + "\n" +
      indent +
      Range(0, board.size).map(col => (if (columns.strips(col).isSolved) " \u2217" else "  ") + addRuler(col)).mkString + "\n" +
      rows.strips.foldLeft("") { (s, row) =>
        s + rowToString(row, maxRowGroups, cellToString) + "\n" +
        (if ((row.coord + 1) % 5 == 0) horizontalRuler else "")
      } +
      indent +
      Range(1, board.size + 1).map(i => StringUtils.leftPad(i.toString, 2) + addRuler(i - 1)).mkString("")
    )
    board
  }

  def columnsToString(columns: List[Strip], colNo: Int): String = {
    columns.foldLeft("") { (s, column) =>
      s + StringUtils.leftPad(columnToString(column, colNo), 2) + addRuler(column.coord)
    }
  }

  def columnToString(column: Strip, colNo: Int): String = {
    val groupSizes = column.getGroupSizes
    if (colNo < groupSizes.size)
      groupSizes(colNo).toString
    else
      " "
  }

  def addRuler(coord: Int) =
    (if ((coord + 1) % 5 == 0) " \u2502" else "")

  def rowToString(row: Strip, maxRowGroups: Int, cellToString: (Cell) => String): String = {
    rowGroupSizesToString(row, maxRowGroups) +
    " \u2502" + StringUtils.leftPad((row.coord + 1).toString, 2) + "\u2502" +
    (if (row.isSolved) "\u2217" else " ") +
    row.cells.map(cell => cellToString(cell) + addRuler(cell.col)).mkString(" ") +
    (row.coord + 1)
  }

  def rowGroupSizesToString(row: Strip, maxRowGroups: Int) = {
    row.getGroupSizes.foldLeft(" " * ((maxRowGroups - row.getGroupSizes.size + 1) * 2)) { (s, size) =>
      s + StringUtils.leftPad(size.toString, 2)
    }
  }

  def renderHighScores(highScores: HighScores) {
    var lastSize = 0
    var rank = 0
    highScores.sorted.foreach { score =>
      rank = if (lastSize != score.boardSize) 1 else rank + 1
      if (rank == 1)
        println
      println(scoreToString(score, rank))
      lastSize = score.boardSize
    }
  }

  def scoreToString(score: Score, rank: Int): String = {
    "%s%3d\t%5.2f\t%s\t%d\t%.2f\t%s".format((if (score.last) "*" else " "), rank, score.score, displayTime(score.time), score.boardSize, score.density, dateFormat.format(score.date))
//    score.score + "\t" +
//    displayTime(score.time) + "\t" +
//    score.date + "\t" +
//    score.boardSize + "\t" +
//    score.density
  }

  def displayTime(sec: Long) = (sec / 60) + ":" + StringUtils.leftPad((sec % 60).toString, 2, '0')

}

