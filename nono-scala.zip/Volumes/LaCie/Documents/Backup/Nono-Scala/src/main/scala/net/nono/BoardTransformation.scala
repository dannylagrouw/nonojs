package net.nono

abstract class BoardTransformation(val board: Board) {

  def getCell(row: Int, col: Int): Cell

}

