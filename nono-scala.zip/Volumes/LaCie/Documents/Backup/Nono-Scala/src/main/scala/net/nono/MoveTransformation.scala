package net.nono

class MoveTransformation(board: Board, val cellStatus: CellStatus.Value, val coords: Point) extends BoardTransformation(board) {

  def getCell(row: Int, col: Int): Cell = {
    if (coords.matches(row, col))
      Cell(board.cells(row)(col), cellStatus)
      //Cell(board.cells(row)(col), if (board.cells(row)(col).status == cellStatus) CellStatus.EMPTY else cellStatus)
    else
      board.cells(row)(col)
  }
}

