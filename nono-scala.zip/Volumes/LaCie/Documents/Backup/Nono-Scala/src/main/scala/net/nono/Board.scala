package net.nono

import org.apache.commons.lang.StringUtils

class Board(val size: Int, val settings: Settings, transformation: Option[BoardTransformation]) {

  val density = settings("density").toDouble

  val cells = for (row <- 0 until size)
    yield for (col <- 0 until size)
      yield transformation match {
        case Some(t) => t.getCell(row, col)
        case None => Cell(row, col, density)
      }

  val getRows = new Strips((
    for (row <- 0 until size)
      yield getRow(row)).toList)

  val getColumns = new Strips((
    for (col <- 0 until size)
      yield getColumn(col)).toList)

  def getRow(rowNum: Int) = new Strip(rowNum, (
    for (col <- 0 until size)
      yield cells(rowNum)(col)).toList)

  def getColumn(colNum: Int) = new Strip(colNum, (
    for (row <- 0 until size)
      yield cells(row)(colNum)).toList)

  def isRowSolved(rowNum: Int) = getRows.strips(rowNum).isSolved

  def isColumnSolved(colNum: Int) = getColumns.strips(colNum).isSolved

  def isSolved = getRows.isSolved && getColumns.isSolved
}

object Board {
  def apply(size: Int, settings: Settings) = new Board(size, settings, None)
  def apply(transformation: BoardTransformation) = new Board(transformation.board.size, transformation.board.settings, Some(transformation))
}

