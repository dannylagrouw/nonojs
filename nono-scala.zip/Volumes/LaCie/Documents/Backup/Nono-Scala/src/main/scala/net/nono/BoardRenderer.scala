package net.nono

abstract class BoardRenderer {

  def renderPlay(board: Board): Board

  def renderSolution(board: Board): Board

  def renderHighScores(highScores: HighScores): Unit
}

