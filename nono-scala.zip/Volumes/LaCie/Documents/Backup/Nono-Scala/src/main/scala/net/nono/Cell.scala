package net.nono

import CellStatus._

class Cell(val row: Int, val col: Int, val solution: CellStatus.Value, val status: CellStatus.Value) {

  def isSolved = {
    (solution == CellStatus.FILLED && status == CellStatus.CROSSED) ||
    (solution == CellStatus.EMPTY && (status == CellStatus.BLANKED || status == CellStatus.EMPTY))
  }
}

object Cell {
  def apply(row: Int, col: Int, density: Double) = new Cell(row, col, (if (Math.random < density) FILLED else EMPTY), EMPTY)
  def apply(original: Cell, status: CellStatus.Value) = new Cell(original.row, original.col, original.solution, status)
}

