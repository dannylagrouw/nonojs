package net.nono

class Point(val x: Int, val y: Int) {

  def matches(x2: Int, y2: Int) = x2 == x && y2 == y
}

object Point {
  def apply(xy: (Int, Int)) = new Point(xy._1, xy._2)
  //def apply(ns: Array[Int]) = new Point(ns(0), ns(1))
}

