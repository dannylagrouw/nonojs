package net.nono

import org.apache.commons.lang.StringUtils

class Settings(val settings: Map[String, String]) {

  def apply(key: String): String = settings(key)

}

object Settings {
  val DEFAULT_SETTINGS = Map("density" -> ".6", "chars" -> "X_.")

  def apply() = new Settings(DEFAULT_SETTINGS)
  def apply(initialSettings: Settings, newSetting: String) = new Settings(initialSettings.settings + split(newSetting))

  private def split(s: String) = if (s.matches(".*[ =]+.*")) {
    val keyval = s.split("[ =]+")
    (keyval(0) -> keyval(1))
  } else {
    (s -> "true")
  }
}

