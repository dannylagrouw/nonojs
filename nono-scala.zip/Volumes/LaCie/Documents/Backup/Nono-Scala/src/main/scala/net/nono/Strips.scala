package net.nono

class Strips(val strips: List[Strip]) {

  def getMaxGroupCount = strips.foldLeft(0) { (accumulated, strip) =>
    val groupSizesSize = strip.getGroupSizes.size
    if (groupSizesSize > accumulated) groupSizesSize else accumulated
  }

  def isSolved = !strips.exists(!_.isSolved)
}

