package net.nono

import java.io._
import java.text.SimpleDateFormat
import java.util.Date

class Score(val time: Long, val date: Date, val boardSize: Int, val density: Double, val last: Boolean) extends Ordered[Score] {

  def this(time: Long, date: Date, boardSize: Int, density: Double) =
    this(time, date, boardSize, density, false)

  def serialize: String = time.toString + "\t" + Score.getDateFormat.format(date) + "\t" +
      boardSize.toString + "\t" + density.toString

  def score: Double = if (density == 0) 0 else (time * density)

  def compare(other: Score) =
    if (boardSize == other.boardSize)
      (score - other.score).toInt
    else
      boardSize - other.boardSize

  def returnAsLast(newLast: Boolean) = new Score(time, date, boardSize, density, newLast)

}

object Score {

  val DATE_FORMAT = "yyyyMMddHHmmss"

  def getDateFormat = new SimpleDateFormat(DATE_FORMAT)

  def apply(time: Long, date: Date, boardSize: Int, density: Double) =
    new Score(time, date, boardSize, density, false)

  def deserialize(s: String): Score = {
    val scoreStr = s.split("\\t")
    new Score(scoreStr(0).toLong, getDateFormat.parse(scoreStr(1)), scoreStr(2).toInt, scoreStr(3).toDouble)
  }

}

