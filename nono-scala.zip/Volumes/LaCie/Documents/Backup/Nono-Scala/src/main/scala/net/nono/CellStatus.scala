package net.nono

object CellStatus extends Enumeration {
  val FILLED, EMPTY, CROSSED, BLANKED = Value
}
