package net.nono

import java.io._
import java.util.Date
import org.apache.commons.lang.StringUtils

object Nono {

  val autoFillSolved = true

  val autoAppendBlanks = true

  val HIGHSCORES_FILE = System.getProperty("user.home") + "/.nono-highscores.dat"

  val HELP_TEXT = "\nAvailable commands:\n" +
    "new <size>\n" +
    "x<col>,<row>\n" +
    "b<col>,<row>\n" +
    "fr<row>\n" +
    "fc<col>\n" +
    "set <option> = <value>\n" +
    "u = undo\n" +
    "sol\n" +
    "show\n" +
    "highscores, hs\n" +
    "quit\n"

  def main(args: Array[String]): Unit = {
    val r = new BufferedReader(new InputStreamReader(System.in))
    var oldBoards = List.empty[Board]
    var settings = Settings()
    var board: Board = Board(15, settings)
    var renderer = new AsciiBoardRenderer
    var time: Long = System.currentTimeMillis
    var highScores = HighScores(new File(HIGHSCORES_FILE))
    var solveTime: Option[Long] = None
    var skipDisplay = false
    renderer.renderPlay(board)
    do {
      print(displayTime(calcTime(time)) + " >> ")
      r.readLine match {
        case s: String if (s.matches("[xb][0-9\\;\\-]{1,20}[, ][0-9\\;\\-]{1,20}")) => {
          println("("+s+")")
          val solution = s.substring(0, 1) match {
            case "x" => CellStatus.CROSSED
            case "b" => CellStatus.BLANKED
            case _ => CellStatus.EMPTY
          }
          oldBoards ::= board
          toCoords(s.substring(1), board.size).foreach { point =>
            board = Board(new MoveTransformation(board, solution, point))
          }
        }
        case s: String if (s.matches("fr[0-9]{1,2}")) => {
          oldBoards ::= board
          board = Board(new FillTransformation(board, s.substring(2).toInt - 1, -1))
        }
        case s: String if (s.matches("fc[0-9]{1,2}")) => {
          oldBoards ::= board
          board = Board(new FillTransformation(board, -1, s.substring(2).toInt - 1))
        }
        case s: String if (s.matches("new [0-9]{1,2}")) => {
          oldBoards ::= board
          val size = s.substring(4).toInt
          if (size % 5 == 0) {
            board = Board(size, settings)
            time = System.currentTimeMillis
            solveTime = None
          } else {
            println("Size must be multiple of 5")
          }
        }
        case s: String if (s.matches("set .+")) => {
          settings = Settings(settings, s.substring(4))
        }
        case "u" => oldBoards match {
          case oldBoard :: Nil => {
            board = oldBoard
            oldBoards = List.empty[Board]
          }
          case oldBoard :: olderBoards => {
            board = oldBoard
            oldBoards = olderBoards
          }
          case _ => {
            println("Nothing to undo")
          }
        }
        case "highscores" | "hs" => {
          renderer.renderHighScores(highScores)
          skipDisplay = true
        }
        case "sol" => {
          renderer.renderSolution(board)
          skipDisplay = true
        }
        case "show" => renderer.renderPlay(board)
        case "quit" | null => {
          highScores.store(new File(HIGHSCORES_FILE))
          return
        }
        case cmd => println("Unknown command " + cmd + HELP_TEXT)
      }
      if (autoFillSolved) {
        board = Board(new AutoFillSolvedTransformation(board))
      }
      if (autoAppendBlanks) {
        board = Board(new AutoAppendBlanksTransformation(board))
      }
      if (solveTime.isEmpty) {
        if (!skipDisplay) {
          renderer.renderPlay(board)
        }
        if (board.isSolved) {
          solveTime = Some(calcTime(time))
          highScores = highScores.add(new Score(solveTime.get, new Date, board.size, settings("density").toDouble))
          println("You solved the board! Enter new <size> to play again.")
          println("Time: " + displayTime(solveTime.get))
        }
      }
      skipDisplay = false
    } while (true)
  }

  def calcTime(sec: Long) = (System.currentTimeMillis - sec) / 1000

  def displayTime(sec: Long) = (sec / 60) + ":" + StringUtils.leftPad((sec % 60).toString, 2, '0')

  def toCoords(s: String, max: Int): Seq[Point] = {
    val ranges = s.split("[, ]").map(toRange(max))
    (for (row <- ranges(0)) yield for (col <- ranges(1)) yield (col, row)).flatten.map(Point.apply)
  }

  def toRange(max: Int)(s: String): Seq[Int] = {
    if (s.contains(";")) {
      s.split(";").flatMap(toRange(max))
    } else if (s.matches("[0-9]+\\-"))
      Range(s.dropRight(1).toInt - 1, max).toList
    else if (s.matches("\\-[0-9]+"))
      Range(0, s.drop(1).toInt).toList
    else if (s.matches("[0-9]+\\-[0-9]+")) {
      val bounds = s.split("-").map(_.toInt)
      Range(bounds(0) - 1, bounds(1)).toList
    } else
      Range(s.toInt - 1, s.toInt).toList
  }

}
