package net.nono

class AutoFillSolvedTransformation(board: Board) extends BoardTransformation(board) {

  def getCell(row: Int, col: Int): Cell = {
    if (board.isRowSolved(row) && board.cells(row)(col).status == CellStatus.EMPTY)
      Cell(board.cells(row)(col), CellStatus.BLANKED)
    else if (board.isColumnSolved(col) && board.cells(row)(col).status == CellStatus.EMPTY)
      Cell(board.cells(row)(col), CellStatus.BLANKED)
    else
      board.cells(row)(col)
  }
}

