package net.nono

import java.io._
import java.text.SimpleDateFormat
import java.util.Date

class HighScores(val previousScores: List[Score]) {

  def add(score: Score): HighScores = new HighScores(score.returnAsLast(true) :: previousScores.map(_.returnAsLast(false)))

  def store(highScoresFile: File): Unit = {
    val w = new BufferedWriter(new FileWriter(highScoresFile))
    previousScores.foreach { scoreDate =>
      w.write(scoreDate.serialize)
      w.newLine
    }
    w.close
  }

  def sorted = previousScores.sorted

}

object HighScores {
  def apply(): HighScores = new HighScores(List.empty[Score])

  def apply(highScoresFile: File): HighScores = {
    if (highScoresFile.exists) {
      new HighScores(readFileToMap(highScoresFile))
    } else {
      apply()
    }
  }

  private def readFileToMap(highScoresFile: File) = {
    var map = List.empty[Score]
    val r = new BufferedReader(new FileReader(highScoresFile))
    var s = r.readLine
    while (s != null) {
      map ::= Score.deserialize(s)
      s = r.readLine
    }
    r.close
    map
  }
}

