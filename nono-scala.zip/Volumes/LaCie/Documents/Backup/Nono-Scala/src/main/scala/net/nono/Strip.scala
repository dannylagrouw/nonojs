package net.nono

// implicit def op cells?
class Strip(val coord: Int, val cells: List[Cell]) {

  def getGroupSizes = getGroupSizesFor(cell => cell.solution == CellStatus.FILLED)

  def getGroupSizesFor(predicate: (Cell) => Boolean) = {
    var sizes = List.empty[Int]
    var inGroup = false
    var size = 0
    cells.foreach { cell => 
      if (predicate(cell)) {
        size = if (inGroup) size + 1 else { inGroup = true; 1 }
      } else {
        if (inGroup) { sizes ::= size; inGroup = false }
      }
    }
    if (inGroup)
      sizes ::= size
    sizes.reverse
  }

  def isSolved = {
    !cells.exists { cell => !cell.isSolved }
  }

}

