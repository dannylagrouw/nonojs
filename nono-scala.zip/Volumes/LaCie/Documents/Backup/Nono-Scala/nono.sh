#!/bin/sh
export JAVA_OPTS="-Dfile.encoding=UTF-8"
java -Dfile.encoding=UTF-8 -cp /Users/danny/Documents/Projecten/Nono-Scala/target/test-classes:/Users/danny/Documents/Projecten/Nono-Scala/target/classes:/Users/danny/.m2/repository/junit/junit/4.5/junit-4.5.jar:/Users/danny/.m2/repository/org/scala-lang/scala-library/2.8.1/scala-library-2.8.1.jar:/Users/danny/.m2/repository/org/scala-lang/scala-compiler/2.8.1/scala-compiler-2.8.1.jar:/Users/danny/.m2/repository/commons-lang/commons-lang/2.4/commons-lang-2.4.jar net.nono.Nono
